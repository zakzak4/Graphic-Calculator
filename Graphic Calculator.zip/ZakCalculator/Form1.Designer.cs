﻿namespace ZakCalculator
{
    partial class Calculator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Calculator));
            this.DISPLAY = new System.Windows.Forms.TextBox();
            this.BUTTON_PERCENT = new ePOSOne.btnProduct.Button_WOC();
            this.BUTTON_BACKSPACE = new ePOSOne.btnProduct.Button_WOC();
            this.BUTTON_PLUS = new ePOSOne.btnProduct.Button_WOC();
            this.BUTTON_MIN = new ePOSOne.btnProduct.Button_WOC();
            this.BUTTON_MULT = new ePOSOne.btnProduct.Button_WOC();
            this.BUTTON_DIV = new ePOSOne.btnProduct.Button_WOC();
            this.BUTTON_CLEAR = new ePOSOne.btnProduct.Button_WOC();
            this.BUTTON_TOTAL = new ePOSOne.btnProduct.Button_WOC();
            this.BUTTON_0 = new ePOSOne.btnProduct.Button_WOC();
            this.BUTTON_6 = new ePOSOne.btnProduct.Button_WOC();
            this.BUTTON_2 = new ePOSOne.btnProduct.Button_WOC();
            this.BUTTON_1 = new ePOSOne.btnProduct.Button_WOC();
            this.BUTTON_5 = new ePOSOne.btnProduct.Button_WOC();
            this.BUTTON_3 = new ePOSOne.btnProduct.Button_WOC();
            this.BUTTON_4 = new ePOSOne.btnProduct.Button_WOC();
            this.BUTTON_9 = new ePOSOne.btnProduct.Button_WOC();
            this.BUTTON_8 = new ePOSOne.btnProduct.Button_WOC();
            this.BUTTON_7 = new ePOSOne.btnProduct.Button_WOC();
            this.SuspendLayout();
            // 
            // DISPLAY
            // 
            this.DISPLAY.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.DISPLAY.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.DISPLAY.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DISPLAY.ForeColor = System.Drawing.Color.White;
            this.DISPLAY.Location = new System.Drawing.Point(19, 46);
            this.DISPLAY.Name = "DISPLAY";
            this.DISPLAY.ReadOnly = true;
            this.DISPLAY.Size = new System.Drawing.Size(293, 42);
            this.DISPLAY.TabIndex = 16;
            this.DISPLAY.Text = "0";
            this.DISPLAY.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // BUTTON_PERCENT
            // 
            this.BUTTON_PERCENT.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.BUTTON_PERCENT.BorderColor = System.Drawing.Color.Black;
            this.BUTTON_PERCENT.ButtonColor = System.Drawing.Color.Chocolate;
            this.BUTTON_PERCENT.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.BUTTON_PERCENT.FlatAppearance.BorderSize = 0;
            this.BUTTON_PERCENT.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.BUTTON_PERCENT.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.BUTTON_PERCENT.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BUTTON_PERCENT.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BUTTON_PERCENT.ForeColor = System.Drawing.Color.Transparent;
            this.BUTTON_PERCENT.Location = new System.Drawing.Point(247, 126);
            this.BUTTON_PERCENT.Name = "BUTTON_PERCENT";
            this.BUTTON_PERCENT.OnHoverBorderColor = System.Drawing.Color.Black;
            this.BUTTON_PERCENT.OnHoverButtonColor = System.Drawing.Color.Coral;
            this.BUTTON_PERCENT.OnHoverTextColor = System.Drawing.Color.Black;
            this.BUTTON_PERCENT.Size = new System.Drawing.Size(65, 65);
            this.BUTTON_PERCENT.TabIndex = 18;
            this.BUTTON_PERCENT.Text = "%";
            this.BUTTON_PERCENT.TextColor = System.Drawing.Color.Black;
            this.BUTTON_PERCENT.UseVisualStyleBackColor = true;
            this.BUTTON_PERCENT.Click += new System.EventHandler(this.BUTTON_PERCENT_Click);
            // 
            // BUTTON_BACKSPACE
            // 
            this.BUTTON_BACKSPACE.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.BUTTON_BACKSPACE.BorderColor = System.Drawing.Color.Black;
            this.BUTTON_BACKSPACE.ButtonColor = System.Drawing.Color.Chocolate;
            this.BUTTON_BACKSPACE.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.BUTTON_BACKSPACE.FlatAppearance.BorderSize = 0;
            this.BUTTON_BACKSPACE.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.BUTTON_BACKSPACE.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.BUTTON_BACKSPACE.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BUTTON_BACKSPACE.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BUTTON_BACKSPACE.ForeColor = System.Drawing.Color.Transparent;
            this.BUTTON_BACKSPACE.Location = new System.Drawing.Point(19, 126);
            this.BUTTON_BACKSPACE.Name = "BUTTON_BACKSPACE";
            this.BUTTON_BACKSPACE.OnHoverBorderColor = System.Drawing.Color.Black;
            this.BUTTON_BACKSPACE.OnHoverButtonColor = System.Drawing.Color.Coral;
            this.BUTTON_BACKSPACE.OnHoverTextColor = System.Drawing.Color.Black;
            this.BUTTON_BACKSPACE.Size = new System.Drawing.Size(65, 65);
            this.BUTTON_BACKSPACE.TabIndex = 17;
            this.BUTTON_BACKSPACE.Text = "⌫";
            this.BUTTON_BACKSPACE.TextColor = System.Drawing.Color.Black;
            this.BUTTON_BACKSPACE.UseVisualStyleBackColor = true;
            this.BUTTON_BACKSPACE.Click += new System.EventHandler(this.BUTTON_BACKSPACE_Click);
            // 
            // BUTTON_PLUS
            // 
            this.BUTTON_PLUS.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.BUTTON_PLUS.BorderColor = System.Drawing.Color.Black;
            this.BUTTON_PLUS.ButtonColor = System.Drawing.Color.Chocolate;
            this.BUTTON_PLUS.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.BUTTON_PLUS.FlatAppearance.BorderSize = 0;
            this.BUTTON_PLUS.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.BUTTON_PLUS.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.BUTTON_PLUS.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BUTTON_PLUS.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BUTTON_PLUS.ForeColor = System.Drawing.Color.Transparent;
            this.BUTTON_PLUS.Location = new System.Drawing.Point(247, 425);
            this.BUTTON_PLUS.Name = "BUTTON_PLUS";
            this.BUTTON_PLUS.OnHoverBorderColor = System.Drawing.Color.Black;
            this.BUTTON_PLUS.OnHoverButtonColor = System.Drawing.Color.Coral;
            this.BUTTON_PLUS.OnHoverTextColor = System.Drawing.Color.Black;
            this.BUTTON_PLUS.Size = new System.Drawing.Size(65, 65);
            this.BUTTON_PLUS.TabIndex = 15;
            this.BUTTON_PLUS.Text = "+";
            this.BUTTON_PLUS.TextColor = System.Drawing.Color.Black;
            this.BUTTON_PLUS.UseVisualStyleBackColor = true;
            this.BUTTON_PLUS.Click += new System.EventHandler(this.BUTTON_PLUS_Click);
            // 
            // BUTTON_MIN
            // 
            this.BUTTON_MIN.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.BUTTON_MIN.BorderColor = System.Drawing.Color.Black;
            this.BUTTON_MIN.ButtonColor = System.Drawing.Color.Chocolate;
            this.BUTTON_MIN.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.BUTTON_MIN.FlatAppearance.BorderSize = 0;
            this.BUTTON_MIN.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.BUTTON_MIN.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.BUTTON_MIN.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BUTTON_MIN.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BUTTON_MIN.ForeColor = System.Drawing.Color.Transparent;
            this.BUTTON_MIN.Location = new System.Drawing.Point(247, 349);
            this.BUTTON_MIN.Name = "BUTTON_MIN";
            this.BUTTON_MIN.OnHoverBorderColor = System.Drawing.Color.Black;
            this.BUTTON_MIN.OnHoverButtonColor = System.Drawing.Color.Coral;
            this.BUTTON_MIN.OnHoverTextColor = System.Drawing.Color.Black;
            this.BUTTON_MIN.Size = new System.Drawing.Size(65, 65);
            this.BUTTON_MIN.TabIndex = 14;
            this.BUTTON_MIN.Text = "-";
            this.BUTTON_MIN.TextColor = System.Drawing.Color.Black;
            this.BUTTON_MIN.UseVisualStyleBackColor = true;
            this.BUTTON_MIN.Click += new System.EventHandler(this.BUTTON_MIN_Click);
            // 
            // BUTTON_MULT
            // 
            this.BUTTON_MULT.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.BUTTON_MULT.BorderColor = System.Drawing.Color.Black;
            this.BUTTON_MULT.ButtonColor = System.Drawing.Color.Chocolate;
            this.BUTTON_MULT.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.BUTTON_MULT.FlatAppearance.BorderSize = 0;
            this.BUTTON_MULT.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.BUTTON_MULT.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.BUTTON_MULT.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BUTTON_MULT.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BUTTON_MULT.ForeColor = System.Drawing.Color.Transparent;
            this.BUTTON_MULT.Location = new System.Drawing.Point(247, 273);
            this.BUTTON_MULT.Name = "BUTTON_MULT";
            this.BUTTON_MULT.OnHoverBorderColor = System.Drawing.Color.Black;
            this.BUTTON_MULT.OnHoverButtonColor = System.Drawing.Color.Coral;
            this.BUTTON_MULT.OnHoverTextColor = System.Drawing.Color.Black;
            this.BUTTON_MULT.Size = new System.Drawing.Size(65, 65);
            this.BUTTON_MULT.TabIndex = 13;
            this.BUTTON_MULT.Text = "X";
            this.BUTTON_MULT.TextColor = System.Drawing.Color.Black;
            this.BUTTON_MULT.UseVisualStyleBackColor = true;
            this.BUTTON_MULT.Click += new System.EventHandler(this.BUTTON_MULT_Click);
            // 
            // BUTTON_DIV
            // 
            this.BUTTON_DIV.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.BUTTON_DIV.BorderColor = System.Drawing.Color.Black;
            this.BUTTON_DIV.ButtonColor = System.Drawing.Color.Chocolate;
            this.BUTTON_DIV.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.BUTTON_DIV.FlatAppearance.BorderSize = 0;
            this.BUTTON_DIV.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.BUTTON_DIV.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.BUTTON_DIV.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BUTTON_DIV.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BUTTON_DIV.ForeColor = System.Drawing.Color.Transparent;
            this.BUTTON_DIV.Location = new System.Drawing.Point(247, 197);
            this.BUTTON_DIV.Name = "BUTTON_DIV";
            this.BUTTON_DIV.OnHoverBorderColor = System.Drawing.Color.Black;
            this.BUTTON_DIV.OnHoverButtonColor = System.Drawing.Color.Coral;
            this.BUTTON_DIV.OnHoverTextColor = System.Drawing.Color.Black;
            this.BUTTON_DIV.Size = new System.Drawing.Size(65, 65);
            this.BUTTON_DIV.TabIndex = 12;
            this.BUTTON_DIV.Text = "÷";
            this.BUTTON_DIV.TextColor = System.Drawing.Color.Black;
            this.BUTTON_DIV.UseVisualStyleBackColor = true;
            this.BUTTON_DIV.Click += new System.EventHandler(this.BUTTON_DIV_Click);
            // 
            // BUTTON_CLEAR
            // 
            this.BUTTON_CLEAR.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.BUTTON_CLEAR.BorderColor = System.Drawing.Color.Black;
            this.BUTTON_CLEAR.ButtonColor = System.Drawing.Color.Chocolate;
            this.BUTTON_CLEAR.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.BUTTON_CLEAR.FlatAppearance.BorderSize = 0;
            this.BUTTON_CLEAR.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.BUTTON_CLEAR.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.BUTTON_CLEAR.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BUTTON_CLEAR.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BUTTON_CLEAR.ForeColor = System.Drawing.Color.Transparent;
            this.BUTTON_CLEAR.Location = new System.Drawing.Point(95, 126);
            this.BUTTON_CLEAR.Name = "BUTTON_CLEAR";
            this.BUTTON_CLEAR.OnHoverBorderColor = System.Drawing.Color.Black;
            this.BUTTON_CLEAR.OnHoverButtonColor = System.Drawing.Color.Coral;
            this.BUTTON_CLEAR.OnHoverTextColor = System.Drawing.Color.Black;
            this.BUTTON_CLEAR.Size = new System.Drawing.Size(141, 65);
            this.BUTTON_CLEAR.TabIndex = 11;
            this.BUTTON_CLEAR.Text = "C";
            this.BUTTON_CLEAR.TextColor = System.Drawing.Color.Black;
            this.BUTTON_CLEAR.UseVisualStyleBackColor = true;
            this.BUTTON_CLEAR.Click += new System.EventHandler(this.BUTTON_CLEAR_Click);
            // 
            // BUTTON_TOTAL
            // 
            this.BUTTON_TOTAL.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.BUTTON_TOTAL.BorderColor = System.Drawing.Color.Black;
            this.BUTTON_TOTAL.ButtonColor = System.Drawing.Color.DarkOrange;
            this.BUTTON_TOTAL.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.BUTTON_TOTAL.FlatAppearance.BorderSize = 0;
            this.BUTTON_TOTAL.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.BUTTON_TOTAL.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.BUTTON_TOTAL.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BUTTON_TOTAL.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BUTTON_TOTAL.ForeColor = System.Drawing.Color.Transparent;
            this.BUTTON_TOTAL.Location = new System.Drawing.Point(95, 425);
            this.BUTTON_TOTAL.Name = "BUTTON_TOTAL";
            this.BUTTON_TOTAL.OnHoverBorderColor = System.Drawing.Color.Black;
            this.BUTTON_TOTAL.OnHoverButtonColor = System.Drawing.Color.OrangeRed;
            this.BUTTON_TOTAL.OnHoverTextColor = System.Drawing.Color.Black;
            this.BUTTON_TOTAL.Size = new System.Drawing.Size(141, 65);
            this.BUTTON_TOTAL.TabIndex = 10;
            this.BUTTON_TOTAL.Text = "=";
            this.BUTTON_TOTAL.TextColor = System.Drawing.Color.Black;
            this.BUTTON_TOTAL.UseVisualStyleBackColor = true;
            this.BUTTON_TOTAL.Click += new System.EventHandler(this.BUTTON_TOTAL_Click);
            // 
            // BUTTON_0
            // 
            this.BUTTON_0.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.BUTTON_0.BorderColor = System.Drawing.Color.Black;
            this.BUTTON_0.ButtonColor = System.Drawing.Color.DarkOrange;
            this.BUTTON_0.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.BUTTON_0.FlatAppearance.BorderSize = 0;
            this.BUTTON_0.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.BUTTON_0.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.BUTTON_0.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BUTTON_0.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BUTTON_0.ForeColor = System.Drawing.Color.Transparent;
            this.BUTTON_0.Location = new System.Drawing.Point(19, 425);
            this.BUTTON_0.Name = "BUTTON_0";
            this.BUTTON_0.OnHoverBorderColor = System.Drawing.Color.Black;
            this.BUTTON_0.OnHoverButtonColor = System.Drawing.Color.OrangeRed;
            this.BUTTON_0.OnHoverTextColor = System.Drawing.Color.Black;
            this.BUTTON_0.Size = new System.Drawing.Size(65, 65);
            this.BUTTON_0.TabIndex = 9;
            this.BUTTON_0.Text = "0";
            this.BUTTON_0.TextColor = System.Drawing.Color.Black;
            this.BUTTON_0.UseVisualStyleBackColor = true;
            this.BUTTON_0.Click += new System.EventHandler(this.BUTTON_0_Click);
            // 
            // BUTTON_6
            // 
            this.BUTTON_6.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.BUTTON_6.BorderColor = System.Drawing.Color.Black;
            this.BUTTON_6.ButtonColor = System.Drawing.Color.DarkOrange;
            this.BUTTON_6.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.BUTTON_6.FlatAppearance.BorderSize = 0;
            this.BUTTON_6.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.BUTTON_6.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.BUTTON_6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BUTTON_6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BUTTON_6.ForeColor = System.Drawing.Color.Transparent;
            this.BUTTON_6.Location = new System.Drawing.Point(171, 273);
            this.BUTTON_6.Name = "BUTTON_6";
            this.BUTTON_6.OnHoverBorderColor = System.Drawing.Color.Black;
            this.BUTTON_6.OnHoverButtonColor = System.Drawing.Color.OrangeRed;
            this.BUTTON_6.OnHoverTextColor = System.Drawing.Color.Black;
            this.BUTTON_6.Size = new System.Drawing.Size(65, 65);
            this.BUTTON_6.TabIndex = 8;
            this.BUTTON_6.Text = "6";
            this.BUTTON_6.TextColor = System.Drawing.Color.Black;
            this.BUTTON_6.UseVisualStyleBackColor = true;
            this.BUTTON_6.Click += new System.EventHandler(this.BUTTON_6_Click);
            // 
            // BUTTON_2
            // 
            this.BUTTON_2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.BUTTON_2.BorderColor = System.Drawing.Color.Black;
            this.BUTTON_2.ButtonColor = System.Drawing.Color.DarkOrange;
            this.BUTTON_2.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.BUTTON_2.FlatAppearance.BorderSize = 0;
            this.BUTTON_2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.BUTTON_2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.BUTTON_2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BUTTON_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BUTTON_2.ForeColor = System.Drawing.Color.Transparent;
            this.BUTTON_2.Location = new System.Drawing.Point(95, 349);
            this.BUTTON_2.Name = "BUTTON_2";
            this.BUTTON_2.OnHoverBorderColor = System.Drawing.Color.Black;
            this.BUTTON_2.OnHoverButtonColor = System.Drawing.Color.OrangeRed;
            this.BUTTON_2.OnHoverTextColor = System.Drawing.Color.Black;
            this.BUTTON_2.Size = new System.Drawing.Size(65, 65);
            this.BUTTON_2.TabIndex = 7;
            this.BUTTON_2.Text = "2";
            this.BUTTON_2.TextColor = System.Drawing.Color.Black;
            this.BUTTON_2.UseVisualStyleBackColor = true;
            this.BUTTON_2.Click += new System.EventHandler(this.BUTTON_2_Click);
            // 
            // BUTTON_1
            // 
            this.BUTTON_1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.BUTTON_1.BorderColor = System.Drawing.Color.Black;
            this.BUTTON_1.ButtonColor = System.Drawing.Color.DarkOrange;
            this.BUTTON_1.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.BUTTON_1.FlatAppearance.BorderSize = 0;
            this.BUTTON_1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.BUTTON_1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.BUTTON_1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BUTTON_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BUTTON_1.ForeColor = System.Drawing.Color.Transparent;
            this.BUTTON_1.Location = new System.Drawing.Point(19, 349);
            this.BUTTON_1.Name = "BUTTON_1";
            this.BUTTON_1.OnHoverBorderColor = System.Drawing.Color.Black;
            this.BUTTON_1.OnHoverButtonColor = System.Drawing.Color.OrangeRed;
            this.BUTTON_1.OnHoverTextColor = System.Drawing.Color.Black;
            this.BUTTON_1.Size = new System.Drawing.Size(65, 65);
            this.BUTTON_1.TabIndex = 6;
            this.BUTTON_1.Text = "1";
            this.BUTTON_1.TextColor = System.Drawing.Color.Black;
            this.BUTTON_1.UseVisualStyleBackColor = true;
            this.BUTTON_1.Click += new System.EventHandler(this.BUTTON_1_Click);
            // 
            // BUTTON_5
            // 
            this.BUTTON_5.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.BUTTON_5.BorderColor = System.Drawing.Color.Black;
            this.BUTTON_5.ButtonColor = System.Drawing.Color.DarkOrange;
            this.BUTTON_5.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.BUTTON_5.FlatAppearance.BorderSize = 0;
            this.BUTTON_5.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.BUTTON_5.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.BUTTON_5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BUTTON_5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BUTTON_5.ForeColor = System.Drawing.Color.Transparent;
            this.BUTTON_5.Location = new System.Drawing.Point(95, 273);
            this.BUTTON_5.Name = "BUTTON_5";
            this.BUTTON_5.OnHoverBorderColor = System.Drawing.Color.Black;
            this.BUTTON_5.OnHoverButtonColor = System.Drawing.Color.OrangeRed;
            this.BUTTON_5.OnHoverTextColor = System.Drawing.Color.Black;
            this.BUTTON_5.Size = new System.Drawing.Size(65, 65);
            this.BUTTON_5.TabIndex = 5;
            this.BUTTON_5.Text = "5";
            this.BUTTON_5.TextColor = System.Drawing.Color.Black;
            this.BUTTON_5.UseVisualStyleBackColor = true;
            this.BUTTON_5.Click += new System.EventHandler(this.BUTTON_5_Click);
            // 
            // BUTTON_3
            // 
            this.BUTTON_3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.BUTTON_3.BorderColor = System.Drawing.Color.Black;
            this.BUTTON_3.ButtonColor = System.Drawing.Color.DarkOrange;
            this.BUTTON_3.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.BUTTON_3.FlatAppearance.BorderSize = 0;
            this.BUTTON_3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.BUTTON_3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.BUTTON_3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BUTTON_3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BUTTON_3.ForeColor = System.Drawing.Color.Transparent;
            this.BUTTON_3.Location = new System.Drawing.Point(171, 349);
            this.BUTTON_3.Name = "BUTTON_3";
            this.BUTTON_3.OnHoverBorderColor = System.Drawing.Color.Black;
            this.BUTTON_3.OnHoverButtonColor = System.Drawing.Color.OrangeRed;
            this.BUTTON_3.OnHoverTextColor = System.Drawing.Color.Black;
            this.BUTTON_3.Size = new System.Drawing.Size(65, 65);
            this.BUTTON_3.TabIndex = 4;
            this.BUTTON_3.Text = "3";
            this.BUTTON_3.TextColor = System.Drawing.Color.Black;
            this.BUTTON_3.UseVisualStyleBackColor = true;
            this.BUTTON_3.Click += new System.EventHandler(this.BUTTON_3_Click);
            // 
            // BUTTON_4
            // 
            this.BUTTON_4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.BUTTON_4.BorderColor = System.Drawing.Color.Black;
            this.BUTTON_4.ButtonColor = System.Drawing.Color.DarkOrange;
            this.BUTTON_4.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.BUTTON_4.FlatAppearance.BorderSize = 0;
            this.BUTTON_4.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.BUTTON_4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.BUTTON_4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BUTTON_4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BUTTON_4.ForeColor = System.Drawing.Color.Transparent;
            this.BUTTON_4.Location = new System.Drawing.Point(19, 273);
            this.BUTTON_4.Name = "BUTTON_4";
            this.BUTTON_4.OnHoverBorderColor = System.Drawing.Color.Black;
            this.BUTTON_4.OnHoverButtonColor = System.Drawing.Color.OrangeRed;
            this.BUTTON_4.OnHoverTextColor = System.Drawing.Color.Black;
            this.BUTTON_4.Size = new System.Drawing.Size(65, 65);
            this.BUTTON_4.TabIndex = 3;
            this.BUTTON_4.Text = "4";
            this.BUTTON_4.TextColor = System.Drawing.Color.Black;
            this.BUTTON_4.UseVisualStyleBackColor = true;
            this.BUTTON_4.Click += new System.EventHandler(this.BUTTON_4_Click);
            // 
            // BUTTON_9
            // 
            this.BUTTON_9.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.BUTTON_9.BorderColor = System.Drawing.Color.Black;
            this.BUTTON_9.ButtonColor = System.Drawing.Color.DarkOrange;
            this.BUTTON_9.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.BUTTON_9.FlatAppearance.BorderSize = 0;
            this.BUTTON_9.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.BUTTON_9.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.BUTTON_9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BUTTON_9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BUTTON_9.ForeColor = System.Drawing.Color.Transparent;
            this.BUTTON_9.Location = new System.Drawing.Point(171, 197);
            this.BUTTON_9.Name = "BUTTON_9";
            this.BUTTON_9.OnHoverBorderColor = System.Drawing.Color.Black;
            this.BUTTON_9.OnHoverButtonColor = System.Drawing.Color.OrangeRed;
            this.BUTTON_9.OnHoverTextColor = System.Drawing.Color.Black;
            this.BUTTON_9.Size = new System.Drawing.Size(65, 65);
            this.BUTTON_9.TabIndex = 2;
            this.BUTTON_9.Text = "9";
            this.BUTTON_9.TextColor = System.Drawing.Color.Black;
            this.BUTTON_9.UseVisualStyleBackColor = true;
            this.BUTTON_9.Click += new System.EventHandler(this.BUTTON_9_Click);
            // 
            // BUTTON_8
            // 
            this.BUTTON_8.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.BUTTON_8.BorderColor = System.Drawing.Color.Black;
            this.BUTTON_8.ButtonColor = System.Drawing.Color.DarkOrange;
            this.BUTTON_8.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.BUTTON_8.FlatAppearance.BorderSize = 0;
            this.BUTTON_8.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.BUTTON_8.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.BUTTON_8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BUTTON_8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BUTTON_8.ForeColor = System.Drawing.Color.Transparent;
            this.BUTTON_8.Location = new System.Drawing.Point(95, 197);
            this.BUTTON_8.Name = "BUTTON_8";
            this.BUTTON_8.OnHoverBorderColor = System.Drawing.Color.Black;
            this.BUTTON_8.OnHoverButtonColor = System.Drawing.Color.OrangeRed;
            this.BUTTON_8.OnHoverTextColor = System.Drawing.Color.Black;
            this.BUTTON_8.Size = new System.Drawing.Size(65, 65);
            this.BUTTON_8.TabIndex = 1;
            this.BUTTON_8.Text = "8";
            this.BUTTON_8.TextColor = System.Drawing.Color.Black;
            this.BUTTON_8.UseVisualStyleBackColor = true;
            this.BUTTON_8.Click += new System.EventHandler(this.BUTTON_8_Click);
            // 
            // BUTTON_7
            // 
            this.BUTTON_7.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.BUTTON_7.BorderColor = System.Drawing.Color.Black;
            this.BUTTON_7.ButtonColor = System.Drawing.Color.DarkOrange;
            this.BUTTON_7.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.BUTTON_7.FlatAppearance.BorderSize = 0;
            this.BUTTON_7.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.BUTTON_7.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.BUTTON_7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BUTTON_7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BUTTON_7.ForeColor = System.Drawing.Color.Transparent;
            this.BUTTON_7.Location = new System.Drawing.Point(19, 197);
            this.BUTTON_7.Name = "BUTTON_7";
            this.BUTTON_7.OnHoverBorderColor = System.Drawing.Color.Black;
            this.BUTTON_7.OnHoverButtonColor = System.Drawing.Color.OrangeRed;
            this.BUTTON_7.OnHoverTextColor = System.Drawing.Color.Black;
            this.BUTTON_7.Size = new System.Drawing.Size(65, 65);
            this.BUTTON_7.TabIndex = 0;
            this.BUTTON_7.Text = "7";
            this.BUTTON_7.TextColor = System.Drawing.Color.Black;
            this.BUTTON_7.UseVisualStyleBackColor = true;
            this.BUTTON_7.Click += new System.EventHandler(this.BUTTON_7_Click);
            // 
            // Calculator
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(29)))), ((int)(((byte)(36)))));
            this.ClientSize = new System.Drawing.Size(333, 511);
            this.Controls.Add(this.BUTTON_PERCENT);
            this.Controls.Add(this.BUTTON_BACKSPACE);
            this.Controls.Add(this.DISPLAY);
            this.Controls.Add(this.BUTTON_PLUS);
            this.Controls.Add(this.BUTTON_MIN);
            this.Controls.Add(this.BUTTON_MULT);
            this.Controls.Add(this.BUTTON_DIV);
            this.Controls.Add(this.BUTTON_CLEAR);
            this.Controls.Add(this.BUTTON_TOTAL);
            this.Controls.Add(this.BUTTON_0);
            this.Controls.Add(this.BUTTON_6);
            this.Controls.Add(this.BUTTON_2);
            this.Controls.Add(this.BUTTON_1);
            this.Controls.Add(this.BUTTON_5);
            this.Controls.Add(this.BUTTON_3);
            this.Controls.Add(this.BUTTON_4);
            this.Controls.Add(this.BUTTON_9);
            this.Controls.Add(this.BUTTON_8);
            this.Controls.Add(this.BUTTON_7);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Calculator";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Zak Calculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private ePOSOne.btnProduct.Button_WOC BUTTON_7;
        private ePOSOne.btnProduct.Button_WOC BUTTON_8;
        private ePOSOne.btnProduct.Button_WOC BUTTON_9;
        private ePOSOne.btnProduct.Button_WOC BUTTON_4;
        private ePOSOne.btnProduct.Button_WOC BUTTON_3;
        private ePOSOne.btnProduct.Button_WOC BUTTON_5;
        private ePOSOne.btnProduct.Button_WOC BUTTON_1;
        private ePOSOne.btnProduct.Button_WOC BUTTON_2;
        private ePOSOne.btnProduct.Button_WOC BUTTON_6;
        private ePOSOne.btnProduct.Button_WOC BUTTON_0;
        private ePOSOne.btnProduct.Button_WOC BUTTON_TOTAL;
        private ePOSOne.btnProduct.Button_WOC BUTTON_CLEAR;
        private ePOSOne.btnProduct.Button_WOC BUTTON_PLUS;
        private ePOSOne.btnProduct.Button_WOC BUTTON_MIN;
        private ePOSOne.btnProduct.Button_WOC BUTTON_MULT;
        private ePOSOne.btnProduct.Button_WOC BUTTON_DIV;
        private System.Windows.Forms.TextBox DISPLAY;
        private ePOSOne.btnProduct.Button_WOC BUTTON_BACKSPACE;
        private ePOSOne.btnProduct.Button_WOC BUTTON_PERCENT;
    }
}

